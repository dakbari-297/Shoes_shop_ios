//
//  ViewController.swift
//  shoes_project_ios
//
//  Created by Student on 11/03/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

